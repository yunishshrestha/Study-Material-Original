Real photos go in this folder — see src/assets/images/README.md
