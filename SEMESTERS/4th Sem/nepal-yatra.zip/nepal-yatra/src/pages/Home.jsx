import { Link } from "react-router-dom";
import MountainDivider from "../components/MountainDivider.jsx";
import places from "../data/places.js";
import "./Home.css";

export default function Home() {
  const featured = places.slice(0, 3);

  return (
    <>
      <section className="hero">
        <div className="hero__peaks" aria-hidden="true">
          <svg viewBox="0 0 1200 400" preserveAspectRatio="none">
            <polygon points="0,400 0,260 140,90 230,210 330,60 430,220 520,140 620,260 700,150 800,240 900,110 1000,230 1100,170 1200,260 1200,400" fill="#1c2c52" />
            <polygon points="0,400 0,320 100,240 200,300 310,190 400,290 500,220 610,310 700,240 810,300 900,220 1010,300 1100,250 1200,320 1200,400" fill="#223058" />
          </svg>
        </div>

        <div className="container hero__content">
          <span className="flag-dots" aria-hidden="true">
            <span></span><span></span><span></span><span></span><span></span>
          </span>
          <h1>
            Nepal, from lakeshore
            <br /> to mountain pass.
          </h1>
          <p className="hero__lede">
            A field guide to the country's best-loved destinations — search by
            name, filter by province, and plan your next trail across all
            seven provinces.
          </p>
          <Link to="/places" className="hero__cta">
            Explore Places
            <svg viewBox="0 0 24 24" width="16" height="16" aria-hidden="true">
              <path d="M5 12h14M13 6l6 6-6 6" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </Link>
        </div>
        <MountainDivider fill="var(--snow)" />
      </section>

      <section className="container home-stats">
        <div>
          <div className="home-stats__num">{places.length}</div>
          <div className="eyebrow">Destinations catalogued</div>
        </div>
        <div>
          <div className="home-stats__num">7</div>
          <div className="eyebrow">Provinces covered</div>
        </div>
        <div>
          <div className="home-stats__num">6</div>
          <div className="eyebrow">Landscape types — lake to wildlife park</div>
        </div>
      </section>

      <section className="container home-featured">
        <div className="home-featured__head">
          <span className="eyebrow">A place to start</span>
          <h2>Three worth building a trip around</h2>
        </div>
        <div className="home-featured__grid">
          {featured.map((p) => (
            <Link to={`/places/${p.id}`} key={p.id} className="home-featured__card">
              <span className="home-featured__district">{p.district}, {p.province}</span>
              <h3>{p.name}</h3>
              <span className="home-featured__link">
                View Details
                <svg viewBox="0 0 24 24" width="13" height="13" aria-hidden="true">
                  <path d="M5 12h14M13 6l6 6-6 6" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
              </span>
            </Link>
          ))}
        </div>
      </section>
    </>
  );
}
