import { Link, useParams } from "react-router-dom";
import PlaceMedia from "../components/PlaceMedia.jsx";
import places from "../data/places.js";
import "./PlaceDetails.css";

export default function PlaceDetails() {
  const { id } = useParams();
  const place = places.find((p) => String(p.id) === id);

  if (!place) {
    return (
      <div className="container details-notfound">
        <h1>We couldn't find that place</h1>
        <p>It may have been removed, or the link is out of date.</p>
        <Link to="/places" className="details__back">
          ← Back to all places
        </Link>
      </div>
    );
  }

  return (
    <div className="details-page">
      <div className="container">
        <Link to="/places" className="details__back">
          ← Back to all places
        </Link>
      </div>

      <div className="container details-page__layout">
        <PlaceMedia place={place} className="details-page__media" />

        <div className="details-page__body">
          <span className="eyebrow">
            {place.city ? `${place.city} · ` : ""}
            {place.district} District
          </span>
          <h1>{place.name}</h1>

          <dl className="details-page__facts">
            <div>
              <dt>District</dt>
              <dd>{place.district}</dd>
            </div>
            <div>
              <dt>Province</dt>
              <dd>{place.province}</dd>
            </div>
          </dl>

          <section className="details-page__section">
            <h2>Description</h2>
            <p>{place.description}</p>
          </section>

          <section className="details-page__section">
            <h2>Best Visiting Season</h2>
            <p>{place.bestSeason}</p>
          </section>

          <section className="details-page__section">
            <h2>Activities</h2>
            <ul className="details-page__activities">
              {place.activities.map((activity) => (
                <li key={activity}>{activity}</li>
              ))}
            </ul>
          </section>
        </div>
      </div>
    </div>
  );
}
