import { useMemo, useState } from "react";
import SearchBar from "../components/SearchBar.jsx";
import Filter from "../components/Filter.jsx";
import PlaceCard from "../components/PlaceCard.jsx";
import places, { provinces } from "../data/places.js";
import "./Places.css";

export default function Places() {
  const [query, setQuery] = useState("");
  const [province, setProvince] = useState("All");

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();

    return places.filter((place) => {
      const matchesProvince = province === "All" || place.province === province;
      if (!matchesProvince) return false;
      if (!q) return true;

      const haystack = [place.name, place.city, place.district, place.province]
        .filter(Boolean)
        .join(" ")
        .toLowerCase();

      return haystack.includes(q);
    });
  }, [query, province]);

  return (
    <div className="container places-page">
      <div className="places-page__head">
        <span className="eyebrow">All Destinations</span>
        <h1>Browse tourist places</h1>
      </div>

      <div className="places-page__controls">
        <SearchBar value={query} onChange={setQuery} />
        <Filter provinces={provinces} value={province} onChange={setProvince} />
      </div>

      <p className="places-page__count">
        {filtered.length} {filtered.length === 1 ? "place" : "places"} found
      </p>

      {filtered.length === 0 ? (
        <div className="places-page__empty">
          <h3>No places found</h3>
          <p>
            Try a different name, or reset the province filter — some
            destinations only appear under "All Provinces".
          </p>
        </div>
      ) : (
        <div className="places-page__grid">
          {filtered.map((place) => (
            <PlaceCard key={place.id} place={place} />
          ))}
        </div>
      )}
    </div>
  );
}
