# Photos go here

Every place in `src/data/places.js` points at an image path like
`/images/phewa.jpg`. No photo files are bundled with this project, so
each card and details page currently shows an illustrated placeholder
instead (see `src/components/PlaceIllustration.jsx`).

To use real photos:

1. Add your image files to the Vite `public/images/` folder (create it
   if it doesn't exist) — files placed in `public/` are served from the
   site root, so `public/images/phewa.jpg` becomes `/images/phewa.jpg`.
2. Make sure the filename matches the `image` field for that place in
   `places.js`.
3. That's it — `PlaceMedia` will render the real photo automatically
   and only fall back to the illustration if the file is missing.
