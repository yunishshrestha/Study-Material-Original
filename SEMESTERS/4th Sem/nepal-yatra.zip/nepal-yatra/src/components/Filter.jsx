import "./Filter.css";

export default function Filter({ provinces, value, onChange }) {
  return (
    <div className="filter">
      <label htmlFor="province-filter" className="eyebrow">
        Province
      </label>
      <select
        id="province-filter"
        value={value}
        onChange={(e) => onChange(e.target.value)}
      >
        <option value="All">All Provinces</option>
        {provinces.map((p) => (
          <option key={p} value={p}>
            {p}
          </option>
        ))}
      </select>
    </div>
  );
}
