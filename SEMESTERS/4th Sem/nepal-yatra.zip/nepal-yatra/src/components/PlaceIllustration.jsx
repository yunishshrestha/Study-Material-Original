const THEMES = {
  lake: { from: "#1c3b6b", to: "#3a6ea5", icon: "lake" },
  temple: { from: "#7a2a45", to: "#c5395f", icon: "temple" },
  hill: { from: "#1e4d3b", to: "#3f8f5f", icon: "hill" },
  wildlife: { from: "#4a3b1f", to: "#8a6a2f", icon: "wildlife" },
  heritage: { from: "#3a2c5e", to: "#6a4f9e", icon: "heritage" },
  mountain: { from: "#22345c", to: "#4a5f8f", icon: "hill" },
};

// A small illustrated stand-in used whenever `place.image` hasn't been
// supplied yet (drop real photos into src/assets/images and point each
// place's `image` field at them to replace this automatically).
export default function PlaceIllustration({ category = "hill", label }) {
  const theme = THEMES[category] || THEMES.hill;
  const gradId = `grad-${category}`;

  return (
    <svg
      className="place-illustration"
      viewBox="0 0 400 260"
      preserveAspectRatio="xMidYMid slice"
      role="img"
      aria-label={label ? `Illustration for ${label}` : "Destination illustration"}
    >
      <defs>
        <linearGradient id={gradId} x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor={theme.from} />
          <stop offset="100%" stopColor={theme.to} />
        </linearGradient>
      </defs>
      <rect width="400" height="260" fill={`url(#${gradId})`} />

      {/* shared ridge silhouette */}
      <path
        d="M0,190 L60,140 L110,175 L170,110 L230,165 L280,120 L340,170 L400,130 L400,260 L0,260 Z"
        fill="rgba(0,0,0,0.18)"
      />

      {theme.icon === "lake" && (
        <>
          <circle cx="320" cy="55" r="26" fill="rgba(255,255,255,0.85)" />
          <path d="M0,205 Q50,190 100,205 T200,205 T300,205 T400,205 V260 H0 Z" fill="rgba(255,255,255,0.12)" />
          <path d="M0,225 Q50,212 100,225 T200,225 T300,225 T400,225 V260 H0 Z" fill="rgba(255,255,255,0.08)" />
        </>
      )}

      {theme.icon === "temple" && (
        <g fill="rgba(255,255,255,0.9)">
          <rect x="170" y="150" width="60" height="70" />
          <polygon points="150,150 250,150 200,110" />
          <rect x="192" y="95" width="16" height="24" />
          <circle cx="200" cy="88" r="7" />
        </g>
      )}

      {theme.icon === "hill" && (
        <>
          <circle cx="330" cy="60" r="24" fill="rgba(255,255,255,0.85)" />
          <path d="M40,205 L110,120 L150,160 L210,90 L280,205 Z" fill="rgba(255,255,255,0.85)" />
          <path d="M110,205 L170,140 L200,165 L250,120 L320,205 Z" fill="rgba(255,255,255,0.6)" />
        </>
      )}

      {theme.icon === "wildlife" && (
        <g fill="rgba(255,255,255,0.85)">
          <ellipse cx="200" cy="150" rx="70" ry="34" />
          <circle cx="145" cy="120" r="26" />
          <polygon points="130,100 138,118 122,118" />
          <polygon points="160,100 168,118 152,118" />
        </g>
      )}

      {theme.icon === "heritage" && (
        <g fill="rgba(255,255,255,0.88)">
          <rect x="185" y="80" width="30" height="130" />
          <polygon points="160,90 240,90 200,55" />
          <rect x="150" y="200" width="100" height="14" />
        </g>
      )}
    </svg>
  );
}
