import { NavLink } from "react-router-dom";
import "./Navbar.css";

export default function Navbar() {
  return (
    <header className="navbar">
      <div className="container navbar__inner">
        <NavLink to="/" className="navbar__brand">
          <span className="navbar__mark" aria-hidden="true">
            <svg viewBox="0 0 40 40" width="26" height="26">
              <polygon points="4,30 14,12 20,22 26,8 36,30" fill="var(--marigold)" />
            </svg>
          </span>
          Nepal Yatra
        </NavLink>
        <nav className="navbar__links">
          <NavLink to="/" end className={({ isActive }) => (isActive ? "active" : "")}>
            Home
          </NavLink>
          <NavLink to="/places" className={({ isActive }) => (isActive ? "active" : "")}>
            Places
          </NavLink>
        </nav>
      </div>
    </header>
  );
}
