// The page's recurring signature element: a layered mountain-ridge skyline
// used to transition between sections, echoing the Himalayan horizon rather
// than a generic gradient or wave divider.
export default function MountainDivider({ flip = false, fill = "var(--snow)" }) {
  return (
    <svg
      className={`mountain-divider${flip ? " flip" : ""}`}
      viewBox="0 0 1200 120"
      preserveAspectRatio="none"
      aria-hidden="true"
    >
      <path
        d="M0,90 L120,45 L230,80 L330,20 L420,70 L520,10 L610,65 L700,30 L800,75 L900,25 L1000,60 L1090,35 L1200,80 L1200,120 L0,120 Z"
        fill={fill}
        opacity="0.55"
      />
      <path
        d="M0,110 L150,60 L260,95 L380,45 L470,90 L580,50 L680,95 L780,55 L880,100 L980,50 L1080,85 L1200,55 L1200,120 L0,120 Z"
        fill={fill}
      />
    </svg>
  );
}
