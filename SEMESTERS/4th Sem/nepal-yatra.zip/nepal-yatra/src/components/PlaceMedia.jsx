import { useState } from "react";
import PlaceIllustration from "./PlaceIllustration.jsx";

// Renders `place.image` if it loads; otherwise falls back to the
// illustrated placeholder so cards never show a broken-image icon.
export default function PlaceMedia({ place, className = "" }) {
  const [failed, setFailed] = useState(false);

  if (failed) {
    return (
      <div className={className}>
        <PlaceIllustration category={place.category} label={place.name} />
      </div>
    );
  }

  return (
    <div className={className}>
      <img
        src={place.image}
        alt={place.name}
        loading="lazy"
        onError={() => setFailed(true)}
      />
    </div>
  );
}
