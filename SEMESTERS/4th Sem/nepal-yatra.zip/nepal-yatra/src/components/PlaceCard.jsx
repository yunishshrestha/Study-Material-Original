import { Link } from "react-router-dom";
import PlaceMedia from "./PlaceMedia.jsx";
import "./PlaceCard.css";

export default function PlaceCard({ place }) {
  return (
    <article className="place-card">
      <PlaceMedia place={place} className="place-card__media" />
      <div className="place-card__body">
        <h3 className="place-card__name">{place.name}</h3>
        <dl className="place-card__meta">
          <div>
            <dt>District</dt>
            <dd>{place.district}</dd>
          </div>
          <div>
            <dt>Province</dt>
            <dd>{place.province}</dd>
          </div>
        </dl>
        <div className="place-card__season">
          <span className="eyebrow">Best Season</span> {place.season}
        </div>
        <Link to={`/places/${place.id}`} className="place-card__cta">
          View Details
          <svg viewBox="0 0 24 24" width="14" height="14" aria-hidden="true">
            <path d="M5 12h14M13 6l6 6-6 6" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </Link>
      </div>
    </article>
  );
}
