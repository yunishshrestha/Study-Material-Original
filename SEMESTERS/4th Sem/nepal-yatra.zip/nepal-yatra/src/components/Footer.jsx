import "./Footer.css";

export default function Footer() {
  return (
    <footer className="site-footer">
      <div className="container site-footer__inner">
        <div>
          <div className="eyebrow" style={{ color: "rgba(255,255,255,0.5)" }}>
            Nepal Yatra
          </div>
          <p className="site-footer__tag">
            A field guide to Nepal's lakes, temples, hill stations and parks —
            built for travellers planning their next trail.
          </p>
        </div>
        <div className="flag-dots" aria-hidden="true">
          <span></span><span></span><span></span><span></span><span></span>
        </div>
      </div>
    </footer>
  );
}
