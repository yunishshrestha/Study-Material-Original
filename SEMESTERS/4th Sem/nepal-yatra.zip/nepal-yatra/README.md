# Nepal Yatra

A browsable guide to tourist destinations across Nepal — search by name,
filter by province, and view details for each place. Built with React,
Vite, and React Router.

## Getting started

This project's dependencies were not installed in the sandbox that built
it (no network access there), so the first run on your machine needs one
extra step:

```bash
npm install
npm run dev
```

Then open the local URL Vite prints (usually `http://localhost:5173`).

To build for production:

```bash
npm run build
npm run preview
```

## What's included

- **16 real destinations** across all 7 provinces, in `src/data/places.js`
  (lakes, temples, hill stations, heritage sites, and national parks).
- **Search** by place name, city, or district (`src/pages/Places.jsx`).
- **Province filter** dropdown, combinable with search.
- **Details page** per place with description, best season, and activities.
- **Illustrated placeholders** for photos — see
  `src/assets/images/README.md` for how to swap in real images.

## Folder structure

```
src/
├── components/       Navbar, SearchBar, Filter, PlaceCard, PlaceMedia,
│                     PlaceIllustration, MountainDivider, Footer
├── pages/            Home, Places, PlaceDetails
├── data/places.js    All destination data
├── assets/images/    Drop real photos here (see README inside)
├── App.jsx           Route definitions
└── main.jsx          Entry point
```

## Bonus ideas not yet built

The brief's optional extras (favorites, dark mode, Google Maps links,
ratings, and localStorage-backed reviews) aren't implemented — the data
model and component structure here should make each one a fairly
contained addition if you want to pick them up next.
